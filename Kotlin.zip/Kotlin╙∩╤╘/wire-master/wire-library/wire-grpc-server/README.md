Compatibility classes to make wire-generated services work with grpc server. Currently used 
alongside `wire-grpc-server-generator`.

This feature is experimental.