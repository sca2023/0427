Generates service code compatible with https://github.com/grpc/grpc.

This feature is experimental.