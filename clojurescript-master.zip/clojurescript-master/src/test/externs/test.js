/**
 * @constructor
 */
var Foo = function() {};
Foo.prototype.wozMethod = function() {
};
/**
 * @return {Foo}
 */
var baz = function() {};
/**
 * @constructor
 */
Foo.Bar = function() {};
/**
 * @return {Foo.Boo}
 */
Foo.Bar.prototype.baz = function() {};
/**
 * @constructor
 */
Foo.Boo = function() {};
Foo.Boo.prototype.woz = function() {};