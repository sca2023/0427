goog.provide("tabby");

tabby.hello = function() {
  return "hello there from tabby";
};
