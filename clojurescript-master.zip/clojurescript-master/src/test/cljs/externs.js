var nth = function(array, n){};
var Calculator = {
  add: function(a, b) {}
};
