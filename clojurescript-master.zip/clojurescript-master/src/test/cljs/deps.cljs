{:externs ["externs.js"]
 :foreign-libs [{:file "calculator_global.js"
                 :provides ["thirdparty.calculator"]}]}
