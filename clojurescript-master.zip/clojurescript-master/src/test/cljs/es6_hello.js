export var sayHello = function() {
    console.log("Hello, world!");
};
