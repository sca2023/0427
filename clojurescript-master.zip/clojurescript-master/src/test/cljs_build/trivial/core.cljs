(ns trivial.core)

(. js/console (log "Hello!"))
