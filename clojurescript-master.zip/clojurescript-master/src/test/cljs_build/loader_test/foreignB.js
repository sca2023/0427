global.foreignB = function() {
    console.log("I'm foreign too!");
};
