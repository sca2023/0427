global.foreignA = function() {
    console.log("I'm foreign!")
};
