(ns loader-test.bar
  (:require [cljs.loader :as loader]))

(enable-console-print!)

(println "Hello from bar!")

(defn woz []
  (println "Woz!"))
