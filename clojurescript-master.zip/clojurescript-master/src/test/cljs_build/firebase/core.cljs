(ns firebase.core
  (:require ["firebase/auth" :as auth]))

