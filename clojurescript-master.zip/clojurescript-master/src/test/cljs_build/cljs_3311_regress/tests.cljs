(ns cljs-3311-regress.tests
  (:require [cljs.test :refer [deftest is]]))

(deftest some-test
  (is (= 1 1)))
