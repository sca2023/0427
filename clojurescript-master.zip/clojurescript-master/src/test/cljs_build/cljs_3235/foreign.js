window.globalLib = {
    woz: function() {

    },
    foz: {
        boz: function() {

        }
    }
};
