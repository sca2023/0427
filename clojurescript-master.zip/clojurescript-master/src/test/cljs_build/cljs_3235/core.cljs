(ns cljs-3235.core
  (:require [some-foreign :refer [woz]]
            [some-foreign$woz :as sf-woz]
            [some-foreign$foz.boz :as sf-foz-boz]
            [react-select :refer [foo bar]]
            [react-select$default :as select]
            [react-select$default.baz :as select-baz]))
