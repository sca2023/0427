(ns foreign-libs-cljs-2334.core
  (:require [mylib]))

(enable-console-print!)

(println "mylib:" mylib)
