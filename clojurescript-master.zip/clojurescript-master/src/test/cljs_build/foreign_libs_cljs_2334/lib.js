import leftPad from 'left-pad';

export var lp = function() {
  return leftPad(42, 5, 0);
}
