(ns code.split.d)

(defn hello []
  (println "Hello from code.split.d."))
