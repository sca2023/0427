var global = {};
function require(){};
function process(){};
