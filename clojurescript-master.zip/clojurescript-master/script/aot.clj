(require '[cljs.closure :as cljsc])
(cljsc/aot-cache-core)
