external = {};

external.lib = {
  send_alert : function (msg) {
    alert("Sending Alert via " + msg + "!");
  }
};
