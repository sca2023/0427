function send_alert(msg) {
  alert("Sending Alert via " + msg + "!");
};
