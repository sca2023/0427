var external = {};
external.lib = {};
external.lib.send_alert = function() {};
