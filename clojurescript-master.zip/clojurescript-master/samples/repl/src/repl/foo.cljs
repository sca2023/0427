(ns repl.foo)

(defn bar [a b]
  (+ a b))